var chi = require('../');
console.log(chi.pdf(0.5, 1));
