<!DOCTYPE HTML>

<?php
// PHP code goes here
if(isset($_POST["var1"])&&isset($_POST["var2"])&&isset($_POST["var3"])&&isset($_POST["var4"]))
{
	$var1 = $_POST["var1"];
	$var2 = $_POST["var2"];
	$var3 = $_POST["var3"];
	$var4 = $_POST["var4"];
	$result = $var1+$var2+$var3+$var4;
	#echo($result);
}
if(isset($_POST["valuesArea"]))
{
	$var = $_POST["valuesArea"][0][4];
	echo($var);
}
?>



<html lang = "en">
  <head>
    <title>formDemo.html</title>
    <meta charset = "UTF-8" />
	 <img src="uvm.png" alt="Banner Image"/>
  </head>
  <body style="position:relative;height:100%;width:100%">
 <!-- <div style="width:200px;float:left;display:inline-block;"> -->
	<div style="width:400px;position:absolute;left:50px;top:110px;"> 
    <h1>Statistical Calculator</h1>
    <form action="index.php" method="post">
      <fieldset style="height:310px;">
        <legend>Variable input</legend>
        <p>
			<label>Variable 1</label>
			<input type="text" name="var1"> 
        </p>
        <p>
			<label>Variable 2</label>
			<input type="text" name="var2"> 
        </p>
		<p>
			<label>Variable 3</label>
			<input type="text" name="var3"> 
        </p>
		<p>
			<label>Variable 4</label>
			<input type="text" name="var4"> 
        </p>
		<p>
			<input type="submit" value="Submit">
		</p>
        <p>
          <label>Output P-value:</label>
		  </br>
			<textarea rows="4" cols="50"> P-value = <?php echo($result); ?> </textarea>
        </p>
      </fieldset>
	 </form>
	</div>
		
		<!--
		<p>Click the button to change the contents of the text area.</p>
		<button type="button" onclick="myFunction()">Try it</button>
		<script type=text/javascript>
		function myFunction() 
		{
			document.getElementById("valuesArea").value = "Fifth Avenue, New York City";
		}
		</script>
		-->
		
		
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.3/require.min.js"></script>-->
<!--<script src="require.js"></script>-->
<!--<script src="https://d3js.org/d3.v4.js"></script>-->
<!--<script src="https://d3js.org/d3.v4.min.js"></script>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/q.js/2.0.3/q.min.js"></script>-->
<!--<script src="http://cdnjs.cloudflare.com/ajax/libs/q.js/0.9.2/q.min.js"></script>-->
<!--<script src="https://raw.githubusercontent.com/kriskowal/q/master/q.js"</script>-->
<!--<script src="https://raw.githubusercontent.com/statgen/locuszoom/master/locuszoom.vendor.min.js"></script>-->
<script src="locuszoom.vendor.min.js"></script>
<script src="https://statgen.github.io/locuszoom/versions/0.5.6/locuszoom.app.min.js"></script>
<link rel="stylesheet" href="locuszoom.css">
<script src="chi2.js"></script>

		
		
		
<script>
function myFunction2()
{	
			//alert("Fun!");
			//$(document).ready(function(){
			//$("#clickButton").click(function(){
			//$(this).hide();
			//var obj = { "name":"John", "age":30, "city":"New York"};
			//Use the JavaScript function JSON.stringify() to convert it into a string.
			//var myJSON = JSON.stringify(obj);
			$(document).ready(function(){
				//$(this).hide();
				$.ajax({
					method: 'POST',
					url: 'script.php',
					data: {players: "Title_sent_from_website"},
					//data: myJSON,
					dataType:'text',
					success: function(data) {
						//	$('#thisDiv').text(data);
						//alert(data);
					}
				});
			});		
			
				function sleepFunction()
				{
					//alert("wait time is over");
					var img = document.createElement("IMG");
					img.src = "rplot.jpg";
					img.height = "300";
					img.width="400"
					$('#imageDiv').html(img); 
					//loadImage('rplot.jpg', 800, 800, '#imageDiv');
					//var img = new Image();
					//img.src = 'rplot.jpg';
					//img.height = "200";
					//img.width = "200";
					//var ctx = canvas.getContext("2d");
					//ctx.drawImage(img, 0, 0, 400, 400);
					//img.appendTo('#imageDiv');
				}
				
				
				function WriteFile()
				{
					var fh = fopen("MyFile.txt", 3); // Open the file for writing
					if(fh!=-1) // If the file has been successfully opened
					{
						var str = "Some text goes here...";
						fwrite(fh, str); // Write the string to a file
						fclose(fh); // Close the file 
					}

				}
				
			try 
			{
				//alert("Hello");
				var area = document.getElementById("valuesArea");
				var values = area.value;
				//var numValues = area.value.length;
				var rows = area.value.split(/\n/);
				var firstLine = rows[0];
				//alert(areaValueString);
				var firstLineCount = firstLine.split(/\s+/).length;
				var lineCount = rows.length;
				
				//Let's sum the rows:
				var rowSums = new Array(lineCount);
				//alert(rowSums.length);
				for (index = 0; index < lineCount; index++) 
				{
					var rowSub = rows[index].split(/\s+/).map(Number);
					//alert(rowSub);
					sum=0;
					for (index2 = 0; index2 < rowSub.length; index2++)
					{
						sum+=rowSub[index2];
					}
					rowSums[index] = sum;
				}
				
				//Let's sum the columns:
				var allVals = area.value.replace(/\n/g," ").split(/\s+/)
				//alert(allVals);
				var numCols = Math.floor(allVals.length/lineCount);
				//alert(numCols);
				
				var colSums = new Array(numCols);
				//alert(colSums.length);
				for (index3 = 0; index3 < numCols; index3++) 
				{
					sum2=0;
					for (index4 = index3; index4 < allVals.length; index4+=numCols)
					{
						sum2+=parseInt(allVals[index4]);
					}
					colSums[index3] = sum2;
				}
				
				//alert(rowSums[1]);
				//alert(colSums[1]);
				var colResults = colSums.join();
				var rowResults = rowSums.join();
				//document.getElementById("outputArea").value = "Row Sums = "+rowResults+"\nColumn Sums = "+colResults"\nValues: "+values.join();
				//setTimeout(sleepFunction, 3000);
				//WriteFile();
				
				
	//DAWEI, Put code here:#################################################################				
	//"values": is a 1D array of the input				
	//"rowSums" is a 1D of sums for each row	
	//colSums is a 1D array of the sums for each column			
	//alert(values);
	//alert(rowSums);
	//alert(colSums);				
	//alert(lineCount);

	var orVarArray = new Array();
	var counterArray = new Array();
	var varWArray = new Array();
	var lnOrArray = new Array();
	var upperArray = new Array();
	var lowerArray = new Array();
	var pValueArray = new Array();
	var sumW=0;
	var sumW2=0;
	var sumWLnOr=0;
	var sumOrVar = 0;
	var sumCounter = 0;
	var outputStringArray = new Array();
	//alert(lineCount);
	for (ind = 0; ind < lineCount; ind++) 
	{
	var rowElements = rows[ind].split(/\s+/).map(Number);
	//alert(rowSub);

	var var1 = rowElements[0];
	var var2 = rowElements[1];
	var var3 = rowElements[2];
	var var4 = rowElements[3];
	var varOr = (var1*var4)/(var2*var3);
	var varLnOr = (1/var1)+(1/var2)+(1/var3)+(1/var4);
	var varW = 1/varLnOr;
		varWArray[ind] = varW;
	var varW2 = varW*varW;
	var lnOr = Math.log(varOr);
		lnOrArray[ind] = lnOr;
	var wLnOr = varW*lnOr;
		sumWLnOr += wLnOr;
	var lower = lnOr-(1.96*Math.sqrt(varLnOr));
		lowerArray[ind] = lower;
	var upper = lnOr+(1.96*Math.sqrt(varLnOr));
		upperArray[ind] = upper;
	var varSe = Math.sqrt(1/varW);
	var varChi = Math.pow((lnOr/varSe),2);
	var orVar = lnOr*lnOr/varLnOr;
		sumOrVar += orVar;
		orVarArray[ind] = orVar;
	var counter = 1;
		sumCounter += counter;
		counterArray[ind] = counter;
		sumW += varW;
		sumW2+= varW2;
		//alert(sumW);
		//alert(sumW2);

	//var pValue = significance([[1,2,3,4],[1,2,3,4],[1,2,3,4],[4,5,100,4]]);
	//alert(pValue);
	
	var pValue2 = significance2(varChi,1);
	pValueArray[ind] = pValue2;
	
	//alert("pValue2 = "+pValue2.toString());
	
	//var lnOr95 = ROUND(J2,2)&" ("&ROUND(K2,2)&","&ROUND(L2,2)&")"
	//above round to nearest 2 decimal points. 

	var lnOr95 = lnOr.toFixed(2)+" ("+lower.toFixed(2)+","+upper.toFixed(2)+")";

	//var Or95 = ROUND(EXP(J2),2)&" ("&ROUND(EXP(K2),2)&","&ROUND(EXP(L2),2)&")"
	//above exp() funciton in excel raises e to the argument power. 			

	var or95 = Math.pow(Math.E,lnOr).toFixed(2)+" ("+Math.pow(Math.E,lower).toFixed(2)+","+Math.pow(Math.E,upper).toFixed(2)+")";		

	var outputArray = [var1,var2,var3,var4,varOr,varLnOr,varW,wLnOr,lnOr,lower,upper,lnOr95,or95,pValue2,varSe,varChi,varW2];
	var outputString = outputArray.join("\t");
	//alert(outputString);

	outputStringArray[ind] = outputString;

	}	

	//alert("done first part");
	var sumWPrime = 0;
	var sumWPrimeLnOr = 0;
	for (ind2 = 0; ind2 < lineCount; ind2++) 
	{
		orVar = orVarArray[ind2];
		//alert("ORVAR= "+orVar);
		counter = counterArray[ind2];
		//alert("counter= "+counter);
		varW = varWArray[ind2];
		//alert("varW= "+varW);
		lnOr = lnOrArray[ind2];
		//alert("lnOr= "+lnOr);
		var varD = (orVar-counter)*sumW/(sumW*sumW-sumW2);
		//alert(sumW);
		var wPrime = 1/(varD+1/varW);
			sumWPrime += wPrime;
		var wPrimeLnOr = wPrime*lnOr;
			sumWPrimeLnOr += wPrimeLnOr;
		var outputArray2 = [wPrime,wPrimeLnOr,orVar,counter];
		var newString = outputArray2.join("\t");
		var oldString = outputStringArray[ind2];
		outputStringArray[ind2] = oldString+"\t"+newString;	
	}
	//alert("done second part")
	
	var varOverallLnOr = 1/sumW;
	var overallLnOr = sumWLnOr/sumW;
	var overallOr = Math.pow(Math.E,overallLnOr);
	var overallLowerLnOr = overallLnOr-(1.96*Math.sqrt(varOverallLnOr));
	var overallUpperLnOr = overallLnOr+(1.96*Math.sqrt(varOverallLnOr));
	var overallLowerOr = Math.pow(Math.E,overallLowerLnOr);
	var overallUpperOr = Math.pow(Math.E,overallUpperLnOr);
	var overallLnOr95 = overallLnOr.toFixed(2)+" ("+overallLowerLnOr.toFixed(2)+","+overallUpperLnOr.toFixed(2)+")";
	var overallOr95 = overallOr.toFixed(2)+" ("+overallLowerOr.toFixed(2)+","+overallUpperOr.toFixed(2)+")";
	var overallSE = Math.sqrt(1/sumW);
	var overallChi = Math.pow((overallLnOr/overallSE),2);
	var pooledP = significance2(overallChi,1);
	var overallW2	= sumW2;
	var overallWPrime =	sumWPrime;
	var overallWPrimeLnOr =	sumWPrimeLnOr;
	var overallOrVar = (overallLnOr*overallLnOr)/varOverallLnOr;
	var chiQ = sumOrVar - overallOrVar;
	var chiQDf = sumCounter-1;
	var cochransQPValue = significance2(chiQ,chiQDf);
	alert(cochransQPValue);
	var headerArray =["a","b","c","d","OR","VarLnOR","W","WLnOR","LnOR","Lower","Upper","LnOR (95% CI)","OR (95% CI)","P value","SE","Chi","W*W","W'","W'LnOR","Ln(OR)2/Varln(OR)","Counter","P(Cochran's Q)"];
	var headerString = headerArray.join("\t");			
	var outputStringFinal = outputStringArray.join("\n");	
	var tableString = headerString+"\n"+outputStringFinal+"\n"+
	"Overall Var Ln(OR) = "+varOverallLnOr+"\n"+
	"Overall LnOr = "+overallLnOr+"\n"+
	"Overall Lower LnOR = "+overallLowerLnOr+"\n"+
	"Overall Upper LnOr = "+overallUpperLnOr+"\n"+
	"Overall LnOr 95% = "+overallLnOr95+"\n"+
	"Overall OR = "+overallOr+"\n"+
	"Overall Lower Or = "+overallLowerOr+"\n"+
	"Overall Upper Or = "+overallUpperOr+"\n"+
	"Overall Or 95% = "+overallOr95+"\n"+
	"OverallSE = "+overallSE+"\n"+
	"OverallChi = "+overallChi+"\n"+
	"pooled P-value = "+pooledP+"\n"+
	"Overall W^2 = "+overallW2+"\n"+
	"Overal W' = "+overallWPrime+"\n"+
	"Overall W' LnOr = "+overallWPrimeLnOr+"\n"+
	"Overall OrVar = "+overallOrVar+"\n"+
	"ChiQ = "+chiQ+"\n"+
	"Q DF = "+chiQDf+"\n"+
	"Cochran's Q P-value = "+cochransQPValue;
	
	document.getElementById('outputArea').value = tableString;		

	var phewas2 = new Array();
	for (ind3 = 0; ind3 < lineCount; ind3++) 
	{
		phewas2[ind3] = {"phenotype":ind3+1,"log_pvalue":Math.log10(pValueArray[ind3]),"beta":lnOrArray[ind3],"ci_start":lowerArray[ind3],"ci_end":upperArray[ind3]};
	}
	alert(phewas2[1].beta);	

}
catch(err)
{
	alert("Error!");
}

var phewas = [
          {"phenotype":"Bone cancer","log_pvalue":0.469,"beta":-0.033,"ci_start":-0.065,"ci_end":0.016},
          {"phenotype":"Neurofibromatosis","log_pvalue":0.319,"beta":-0.018,"ci_start":-0.033,"ci_end":0.003},
          {"phenotype":"Hypothyroidism","log_pvalue":0.707,"beta":-0.01975,"ci_start":-0.081,"ci_end":0.047},
          {"phenotype":"Type 1 diabetes","log_pvalue":0.5681,"beta":-0.00425,"ci_start":-0.113,"ci_end":0.049},
          {"phenotype":"Type 2 diabetes","log_pvalue":5.6754,"beta":-0.02825,"ci_start":-0.063,"ci_end":-0.005},
          {"phenotype":"Abnormal glucose","log_pvalue":0.545,"beta":-0.02225,"ci_start":-0.074,"ci_end":0.042},
          {"phenotype":"Impaired fasting glucose","log_pvalue":0.5681,"beta":0.01,"ci_start":-0.029,"ci_end":0.045},
          {"phenotype":"Diabetic retinopathy","log_pvalue":0.437,"beta":0.02475,"ci_start":-0.002,"ci_end":0.052},
          {"phenotype":"Hypoglycemia","log_pvalue":0.647,"beta":-0.021,"ci_start":-0.089,"ci_end":0.078},
          {"phenotype":"Adrenal hyperfunction","log_pvalue":0.8561,"beta":0.0275,"ci_start":-0.021,"ci_end":0.091},
          {"phenotype":"Proteinuria","log_pvalue":0.40803,"beta":0.0385,"ci_start":-0.018,"ci_end":0.121},
          {"phenotype":"Hypocalcemia","log_pvalue":0.517,"beta":-0.0375,"ci_start":-0.081,"ci_end":-0.015},
          {"phenotype":"Disorders of bilirubin excretion","log_pvalue":0.776,"beta":-0.00775,"ci_start":-0.093,"ci_end":0.105},
          {"phenotype":"Morbid obesity","log_pvalue":1.048,"beta":-0.00625,"ci_start":-0.035,"ci_end":0.068},
          {"phenotype":"Megaloblastic anemia","log_pvalue":2.28,"beta":0.032,"ci_start":0.022,"ci_end":0.038},
          {"phenotype":"Pancytopenia","log_pvalue":1.178,"beta":-0.002,"ci_start":-0.027,"ci_end":0.032},
          {"phenotype":"Primary thrombocytopenia","log_pvalue":2.231,"beta":0.00925,"ci_start":-0.079,"ci_end":0.057},
          {"phenotype":"Aphasia","log_pvalue":0.829,"beta":-0.02175,"ci_start":-0.053,"ci_end":0.017},
          {"phenotype":"Schizophrenia","log_pvalue":0.814,"beta":-0.032,"ci_start":-0.077,"ci_end":-0.006},
          {"phenotype":"Obsessive-compulsive disorders","log_pvalue":9.47,"beta":-0.0115,"ci_start":-0.041,"ci_end":0.09},
          {"phenotype":"Encephalitis","log_pvalue":0.1551,"beta":0.007,"ci_start":-0.039,"ci_end":0.02},
          {"phenotype":"Hypersomnia","log_pvalue":0.864,"beta":-0.02625,"ci_start":-0.105,"ci_end":0.089},
          {"phenotype":"Parkinson's disease","log_pvalue":2.0334,"beta":-0.0275,"ci_start":-0.043,"ci_end":-0.007},
          {"phenotype":"Epilepsy","log_pvalue":0.456,"beta":-0.01675,"ci_start":-0.029,"ci_end":0.013},
          {"phenotype":"Complex regional/central pain syndrome","log_pvalue":0.0404,"beta":-0.00325,"ci_start":-0.035,"ci_end":0.05},
          {"phenotype":"Retinal detachments and defects","log_pvalue":0.876,"beta":0.00875,"ci_start":-0.02,"ci_end":0.069},
          {"phenotype":"Fuchs' dystrophy","log_pvalue":17.3972,"beta":-0.037,"ci_start":-0.071,"ci_end":-0.006},
          {"phenotype":"Myopia","log_pvalue":0.52,"beta":0.0365,"ci_start":-0.005,"ci_end":0.054},
          {"phenotype":"Scleritis and episcleritis","log_pvalue":1.966,"beta":0.021,"ci_start":-0.035,"ci_end":0.116},
          {"phenotype":"Otosclerosis","log_pvalue":1.274,"beta":-0.031,"ci_start":-0.046,"ci_end":-0.002},
          {"phenotype":"Cholesteatoma","log_pvalue":0.616,"beta":-0.01575,"ci_start":-0.057,"ci_end":0.071},
          {"phenotype":"Meniere's disease","log_pvalue":0.424,"beta":-0.02075,"ci_start":-0.048,"ci_end":0.022},
          {"phenotype":"Labyrinthitis","log_pvalue":1.44,"beta":0.012,"ci_start":0,"ci_end":0.028},
          {"phenotype":"Coronary atherosclerosis","log_pvalue":5.444,"beta":-0.00025,"ci_start":-0.02,"ci_end":0.013},
          {"phenotype":"Endocarditis","log_pvalue":2.9893,"beta":-0.03475,"ci_start":-0.076,"ci_end":0.007},
          {"phenotype":"Cardiomyopathy","log_pvalue":1.4141,"beta":0.01425,"ci_start":-0.008,"ci_end":0.037},
          {"phenotype":"Atrial flutter","log_pvalue":0.884,"beta":-0.02725,"ci_start":-0.057,"ci_end":0.003}
        ];

        var y2_ticks = [];
        var y_offset = 1;
        phewas2.forEach(function(p){
            p.y_offset = y_offset;
            y2_ticks.push({
                y: y_offset,
                text: p.phenotype,
                style: {
                    "font-weight": "bold",
                    "text-anchor": "start"
                }
            });
            y_offset += 1;
        });

        var data_sources = new LocusZoom.DataSources()
          .add("base", ["StaticJSON", phewas2]);

        var layout = {
            width: 400,
            height: 400,
            responsive_resize: true,
            panels: [
                {
                    id: "phewas",
					backcolor: "#fcf9f9",
                    width: 400,
                    height: 400,
                    proportional_width: 1,
                    margin: { top: 20, right: 220, bottom: 50, left: 20 },
                    inner_border: "rgba(210, 210, 210, 0.85)",
                    axes: {
                        x: {
                            label: "Beta",
                            label_offset: 33
                        },
                        y2: {
                            ticks: y2_ticks
                        }
                    },
                    legend: {
                        origin: { x: 250, y: 0 },
                        orientation: "vertical"
                    },
                    data_layers: [
                        {
                            id: "phewaspvalues",
                            type: "forest",
                            z_index: 1,
                            point_shape: "square",
                            point_size: {
                                scale_function: "interpolate",
                                field: "log_pvalue",
                                parameters: {
                                    breaks: [0, 10],
                                    values: [60, 160],
                                    null_value: 50
                                }
                            },
                            color: {
                                scale_function: "interpolate",
                                field: "log_pvalue",
                                parameters: {
                                    breaks: [0, 10],
                                    values: ["#fee8c8","#b30000"],
                                    null_value: "#B8B8B8"
                                }
                            },
                            legend: [
                                { label: "-log10 p-value" },
                                { shape: "square", class: "lz-data_layer-forest", color: "#fdd49e", size: 60, label: "< 2" },
                                { shape: "square", class: "lz-data_layer-forest", color: "#fdbb84", size: 80, label: "2 - 4" },
                                { shape: "square", class: "lz-data_layer-forest", color: "#fc8d59", size: 100, label: "4 - 6" },
                                { shape: "square", class: "lz-data_layer-forest", color: "#ef6548", size: 120, label: "6 - 8" },
                                { shape: "square", class: "lz-data_layer-forest", color: "#d7301f", size: 140, label: "8 - 10" },
                                { shape: "square", class: "lz-data_layer-forest", color: "#b30000", size: 160, label: "10+" }
                            ],
                            id_field: "phenotype",
                            fields: ["phenotype", "log_pvalue", "log_pvalue|logtoscinotation", "beta", "ci_start", "ci_end", "y_offset"],
                            x_axis: {
                                field: "beta",
                                floor: -1.0,
                                ceiling: 1.0
                            },
                            y_axis: {
                                axis: 2,
                                field: "y_offset",
                                floor: 0,
                                ceiling: y_offset
                            },
                            confidence_intervals: {
                                start_field: "ci_start",
                                end_field: "ci_end"
                            },
                            highlighted: {
                                onmouseover: "on",
                                onmouseout: "off"
                            },
                            selected: {
                                onclick: "toggle_exclusive",
                                onshiftclick: "toggle"
                            },
                            tooltip: {
                                closable: true,
                                show: { or: ["highlighted", "selected"] },
                                hide: { and: ["unhighlighted", "unselected"] },
                                html: "<strong>{{phenotype}}</strong><br>"
                                    + "P Value: <strong>{{log_pvalue|logtoscinotation}}</strong><br>"
                                    + "Odds Ratio: <strong>{{beta}}</strong><br>"
                                    + "95% Conf. Interval: <strong>[ {{ci_start}} {{ci_end}} ]</strong>"
                            }
                        },
                        {
                            id: "zeroline",
                            type: "orthogonal_line",
                            z_index: 0,
                            orientation: "vertical",
                            offset: 0,
                            y_axis: {
                                axis: 2
                            }
                        }
                    ]
                }
            ]
        };

        var plot = LocusZoom.populate("#plot", data_sources, layout);	  
	  
}

</script>

	<div id="thisDiv" style="width:400px;height:400px;position:absolute;left:500px;top:200px;">
		 <fieldset style="height:300px;">
		 <p>
			<label>Input rows and columns:</label>
			</br>
			<textarea rows="15" cols="50" id="valuesArea" name ="valuesArea[]" > Paste rows and columns here </textarea>
			<button type="button" onclick="myFunction2()">Try it</button>
        </p>
		</fieldset>
	</div>	
	
	<div style="width:400px;height:400px;position:absolute;left:950px;top:200px;">
		<fieldset style="height:300px;">
		 <p>
			<label>Output:</label>
			</br>
			<textarea rows="15" cols="50" id="outputArea" name ="outputArea" wrap="off" style="overflow-x:scroll;" > Results are output here. </textarea>
        </p>
		</fieldset>
	</div>
	

<div id="plot" style="width:400px;height:400px;position:absolute;left:1400px;top:160px;">

      <hr>

      <div class="row">
        <footer style="text-align: center;">
          &copy; Copyright 2016 <a href="https://github.com/statgen">The University of Michigan Center for Statistical Genetics</a><br>
        </footer>
      </div>


    </div>
	<!--
	<div id="imageDiv" style="width:400px;height:400px;position:absolute;left:1400px;top:200px;">
	</div>
	-->
	
	<img src="mmg_2.jpg" alt="Banner Image" height="300" width=100% style="position:absolute; top:600px; left:0px;"/>
  </body>
</html>
